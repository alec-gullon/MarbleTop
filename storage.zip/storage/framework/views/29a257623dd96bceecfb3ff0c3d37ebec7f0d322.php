<?php $__env->startSection('content'); ?>

    <login-form inline-template>
        <div class="LoginForm">
            <h1>Log In</h1>

            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <div class="ErrorBox">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

            <form action="/login/" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

                <label for="email">Username</label>
                <input type="text" name="email" v-model="email" required />

                <label for="password">Password</label>
                <input type="password" name="password" v-model="password" required />

                <input type="submit" class="Button is-primary" :class="{'is-disabled': !formReady}" value="Sign In" />
            </form>
        </div>
    </login-form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Work\Projects\MarbleTop\resources\views/login.blade.php ENDPATH**/ ?>