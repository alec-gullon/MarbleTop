<?php $__env->startSection('content'); ?>

    <div class="Stripes">
        <div class="stripe-one"></div>
        <div class="stripe-two"></div>
        <div class="stripe-three"></div>
        <div class="stripe-four"></div>
        <div class="stripe-five"></div>
        <div class="stripe-six"></div>
    </div>

    <div class="Hero">

        <h1>Ready to cook something <span class="highlighted">amazing?</span></h1>

        <div class="icons">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <use xlink:href="/images/icons/home.svg#icon"></use>
            </svg>

            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <use xlink:href="/images/icons/heart.svg#icon"></use>
            </svg>

            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <use xlink:href="/images/icons/shopping-cart.svg#icon"></use>
            </svg>
        </div>

        <div class="buttons">
            <a href="/login/" class="Button is-primary has-shadow">Sign In</a>

            <a href="/account/create/" class="Button is-secondary has-shadow">Create Account</a>
        </div>

    </div>

    <div class="FeatureBoxes">
        <div class="box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <use xlink:href="/images/icons/bug.svg#bug"></use>
            </svg>
            <h2>Let's cook something amazing</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aspernatur ea, id illo
                magnam quas? Amet in itaque possimus? Corporis eveniet maiores sequi. Cupiditate facere nemo
                nisi odit perspiciatis tempora!
            </p>
        </div>
        <div class="box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <use xlink:href="/images/icons/bug.svg#bug"></use>
            </svg>
            <h2>Let's cook something amazing</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aspernatur ea, id illo
                magnam quas? Amet in itaque possimus? Corporis eveniet maiores sequi. Cupiditate facere nemo
                nisi odit perspiciatis tempora!
            </p>
        </div>
        <div class="box">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <use xlink:href="/images/icons/bug.svg#bug"></use>
            </svg>
            <h2>Let's cook something amazing</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aspernatur ea, id illo
                magnam quas? Amet in itaque possimus? Corporis eveniet maiores sequi. Cupiditate facere nemo
                nisi odit perspiciatis tempora!
            </p>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Work\Projects\MarbleTop\resources\views/welcome.blade.php ENDPATH**/ ?>