@extends('app')

@section('content')
    Welcome to your home!
@endsection
