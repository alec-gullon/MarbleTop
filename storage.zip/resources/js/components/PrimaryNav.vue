<template>
    <div class="PrimaryNav">

        <div class="bar">
            <svg class="hamburger" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" @click="toggleMobileNav">
                <use xlink:href="/images/icons/menu.svg#menu"></use>
            </svg>
            <a href="/" class="logo">
                <img src="/images/logo.svg" />
            </a>
        </div>

        <div class="mobile" :class="{'is-active': mobileNavActive}">
            <div class="header">
                <form method="POST" action="/logout" v-if="authenticated">
                    <input type="hidden" name="_token" :value="csrftoken" />
                    <input type="submit" class="Button" value="Logout" />
                </form>
                <a href="/login" class="Button" v-else>Log In</a>

                <ul class="options">
                    <li>
                        <img src="/images/icons/document.svg" /><a href="#">Ingredients</a>
                    </li>
                    <li>
                        <img src="/images/icons/document.svg" /><a href="#">Recipes</a>
                    </li>
                    <li>
                        <img src="/images/icons/document.svg" /><a href="#">Saved Plans</a>
                    </li>
                </ul>
            </div>
            <div class="footer">
                <a href="/#">About MarbleTop</a>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        props: {
            'authenticated': {
                type: Boolean,
                default: false
            },
            'csrftoken': {
                type: String,
                default: ''
            }
        },
        methods: {
            toggleMobileNav: function() {
                this.mobileNavActive = true;
            }
        },
        data: function() {
            return {
                mobileNavActive: false
            }
        }
    }

</script>
