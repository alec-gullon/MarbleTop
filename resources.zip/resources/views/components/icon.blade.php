<svg xmlns="http://www.w3.org/2000/svg">
    <use xlink:href="/images/icons.svg#{{ $key }}"></use>
</svg>
